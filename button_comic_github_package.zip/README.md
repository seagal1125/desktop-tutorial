
# Button - 短篇懸疑漫畫

改編自 Richard Matheson 的短篇小說《Button, Button》  
以四格漫畫形式呈現，道出一個關於道德抉擇與報應的故事。

## GitHub Pages 網址
啟用 GitHub Pages 後，請瀏覽 `https://你的帳號.github.io/你的repo名稱/`

## 使用說明
將以下兩個檔案上傳至你的 GitHub Repository：
- `index.html`
- `four_panel_button_comic_tc_fixed.png`

並於 GitHub Pages 設定頁選擇 `main` 分支與 root 資料夾，即可發布漫畫網站。
